# What?

![](http://i3.photobucket.com/albums/y83/SpaceGirl3900/LOLCat-Rainbow.jpg)

## Screenshot

![](https://github.com/busyloop/lolcat/raw/master/ass/screenshot.png)

## Installation

```bash
$ gem install lolcat
```
